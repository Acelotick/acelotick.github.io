setprop ro.config.rm_preload_enabled 1
setprop debug.sf.nobootanimation 0
setprop ro.config.hw_quickpoweron false